<?php
include 'includes/header.php';
include 'includes/nav.php' ?>
      <div class="main">
      <div class="container">
      <div class="row">
        <div class="col-md-12  headtitle">
          <h1 class="text-center heading">List of Participants Admin </h1>
    <hr>

        </div>
          <br>
          <br>
          <br>
          <div class="col-md-12 text-center addp">
            <img src="imgs/logo-upops-2.jpg" alt="logo-upops-2">
          </div>


      </div>


    </div>
</div>

  </body>
</html>
