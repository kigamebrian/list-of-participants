<?php include 'includes/header.php'?>
<?php include 'includes/nav.php';
$sql = "SELECT * FROM components";
$res = mysqli_query($connection, $sql);


if(isset($_POST['submit']))
{
$comp = sanitize($_POST['component']);

}
?>

  <div class="main">
  <div class="container">
  <div class="row">
    <div class="col-md-12  headtitle">
      <h1 class="text-center heading">List of Participants admin</h1>
      <hr>

    </div>

    <div class="col-md-6 addp">
      <div class="panel panel-default">
        <div class="panel-heading ">Select component to View</div>
        <div class="panel-body">
          <form action="clinks.php" method="post">
            <div class="form-group">
              <label for="component"></label>
              <select class="form-control" name="component">
                <?php
                  while ($row = mysqli_fetch_array($res)) {
                    $comp_id=$row['id'];
                    $comp_title = $row['component_title'];
                    echo "<option value='$comp_id'>$comp_title</option>";
                  }
                 ?>
                 </select>
            </div>

            <div class="form-group">
              <input type="submit" name="part_add" value="next" class="btn btn-primary">
            </div>
          </form>


        </div>
      </div>
    </div>



  </div>
</div>
</div>
</html>
</body>
