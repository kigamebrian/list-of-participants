<?php include 'includes/header.php'?>
<?php include 'includes/nav.php' ?>
  <div class="main">
  <div class="container">
  <div class="row">
    <div class="col-md-12  headtitle">
      <h1 class="text-center heading">List of Participants admin</h1>
      <hr>

    </div>

    <div class="col-md-4 addp">
      <div class="panel panel-default">
        <div class="panel-heading text-center">Add component</div>
        <div class="panel-body">
          <form action="includes/functions.php" method="post">
            <div class="form-group">
              <input type="text" name="comp_title" placeholder="component Title" class="form-control">
            </div>
            <div class="form-group">
              <input type="submit" name="comp_add" value="Add Component" class="btn btn-primary">
            </div>
          </form>


        </div>
      </div>
    </div>
    <div class="col-sm-8 addp">
      <div class="panel panel-default">
        <div class="panel-heading text-center">Add component</div>
        <div class="panel-body">
         <table class="table table-bordered table-striped table-hover" id="myTable">
           <thead>
             <th>Component Id</th>
             <th>Component Title</th>
              <th>Delete</th>
           </thead>
           <tbody>
             <?php show_component(); ?>
           </tbody>
         </table>
</div>
</div>
</div>


  </div>
</div>
</div>
<p> <i>created by kigz</i> </p>
<script type="text/javascript">
$(document).ready( function () {
  $('#myTable').DataTable();
} );
</script>

</body>
</html>
