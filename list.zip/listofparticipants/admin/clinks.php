<?php
$ab=($_POST['component']);

echo $ab;
header( "Location:viewparticipant.php?ids=$ab" );
?>
