<?php require_once $_SERVER['DOCUMENT_ROOT'].'/listofparticipants/core/init.php';
include 'includes/functions.php';?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta name="viewport"  initial-scale="1">
    <title>list of Participants</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
  </head>
  <body>
    <div class="container">
