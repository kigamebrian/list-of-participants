<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/listofparticipants/core/init.php';

  function add_component(){
  global $connection;

  if (isset($_POST['comp_add'])) {
      if (empty($_POST['comp_title'])) {
        header("Location: ../add_component.php?Field_cannot_be_empty");
      }else{
        $comp_title = sanitize($_POST['comp_title']);
        $query = "INSERT INTO components(Component_title)VALUES('$comp_title')";
        $result = mysqli_query($connection, $query);

        if (!$result) {
          die("Could not send data " . mysqli_error($connection));
        }
        else{
          header("Location: ../add_component.php?component_added");
        }

      }
  }

}
add_component();

function show_component(){
  global $connection;
  $query = "SELECT * FROM components";
  $result = mysqli_query($connection, $query);

  while ($row = mysqli_fetch_assoc($result)) {
    $comp_id = $row['id'];
    $comp_title = $row['component_title'];

    echo "<tr>";
    echo "<td>{$comp_id}</td>";
    echo "<td>{$comp_title}</td>";
    echo "<td><a href='add_component.php?delete_comp={$comp_id}'>Delete</a></td>";
    echo "</tr>";
  }
}

function delete_component(){
  global $connection;
  if (isset($_GET['delete_comp'])) {
    $comp_id = $_GET['delete_comp'];
    $query = "DELETE FROM components WHERE $comp_id =id";
    $result = mysqli_query($connection, $query);
    if (!$result) {
      die("Could not delete data " . mysqli_error($connection));
    }
    else{
      header("Location: add_component.php?component_deleted");
    }
  }
}
delete_component();

function add_participant(){
  global $connection;
  if (isset($_POST['part_add'])) {
    $name = sanitize($_POST['name']);
    $participant_comp= sanitize($_POST['component']);
    $institution = sanitize($_POST['institution']);
  // get the cat id
    $sql=mysqli_query($connection,"SELECT id FROM components WHERE component_title='$participant_comp'");
    $row=mysqli_fetch_array($sql);
    $participant_comp_id=$row['id'];
    $email =$_POST['email'];

    $query = "INSERT INTO participants(name,participant_component,participant_component_id,institution,email)
    VALUES('$name','$participant_comp','$participant_comp_id','$institution','$email')";
    $result = mysqli_query($connection, $query);
    if (!$result) {
      die("Could not send data " . mysqli_error($connection));
      header("Location: ../add_participant.php");
    }else{
      header("Location: ../add_participant.php");
    echo "<p class='bg-success'>participant added successfuly";
    }
  }
}

add_participant();
