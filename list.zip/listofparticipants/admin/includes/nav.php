<div class="sidenav">
<a href="index.php">Admin</a>
<a href="javascript:;" data-toggle="collapse" data-target="#demo"><i class="fa fa-fw fa-send"></i>Components<i class="fa fa-fw fa-caret-down"></i></a>
<ul id="demo" class="collapse">
    <li>
        <a href="add_component.php">Add component</a>
    </li>
    <li>
        <a href="add_participant.php">Add Participant</a>
    </li>
    <li>
        <a href="view.php">view Participants</a>
    </li>

</ul>

</div>
