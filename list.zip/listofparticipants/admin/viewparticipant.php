<?php include 'includes/header.php'?>
<?php include 'includes/nav.php';
$sql = "SELECT * FROM components";
$res = mysqli_query($connection, $sql);

$cid=$_REQUEST['ids'];
?>

  <div class="main">
  <div class="container">
  <div class="row">
    <div class="col-md-12  headtitle">
      <h1 class="text-center heading">List of Participants admin</h1>
      <hr>

    </div>

    <div class="col-md-12 addp">
      <div class="panel panel-default">
        <div class="panel-heading ">Select component to View</div>
        <div class="panel-body">
          <?php
          $sql = "SELECT * FROM participants WHERE participant_component_id ='$cid' " ;
          $rs_result = $connection->query($sql);

          ?>
            <table  class="table table-bordered table-striped table-condensed border-0" id="myTable">
                <thead class="bg-success white"><th>#</th><th>Name</th> <th>Institution</th><th>Email</th></thead>
                <?php
                $i=1;
                while ($row = mysqli_fetch_assoc($rs_result)) {
                ?>
                <tr>
                <th class="border-0"scope="row"><?=$i;?></th>
                <td class="border-0"><?=$row["name"]; ?></td>
                <td class="border-0"><?=$row["institution"]; ?></td>
                <td class="border-0"><?=$row["email"]; ?></td>
              </tr>
              <?php
              $i++;
              };
              ?>
            </table>
          </div>
      </div>
    </div>



  </div>
</div>
</div>
<script type="text/javascript">
$(document).ready( function () {
    $('#myTable').DataTable();
} );

</script>

</body>
</html>
