<?php
session_start();
$db_host = "localhost";
$db_user = "brian";
$db_pass = "root";
$db_name = "list_of_participants";

$connection = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
date_default_timezone_set('Africa/Nairobi');

if (!$connection) {
  die("Couldn't connect to the database " . mysqli_error($connection));
}
require_once $_SERVER['DOCUMENT_ROOT'].'/listofparticipants/config.php';
require_once BASEURL.'helpers/helpers.php';
