<!--brian kigame-->
<?php
function display_errors($errors){
  $display ='<ul class="bg-danger">';
  foreach($errors as $error){
    $display .= '<li>'.$error.'</li>';
  }
  $display .= '</ul>';
  return $display;
}
function sanitize($dirty){
  $dirty=htmlspecialchars($dirty);
  $dirty=stripslashes($dirty);
  $dirty=strip_tags($dirty);
  $dirty=htmlentities($dirty,ENT_QUOTES,"UTF-8");
  return $dirty;

}

function login($user_id){
  $_SESSION['login_user']= $user_id;
	$_SESSION['loggedin_time'] = time();
  global $connection;
  $date = date("Y-m-d H:i:s");
  $connection->query("UPDATE users SET last_login='$date' WHERE id ='$user_id'");
  $_SESSION['success_flash']='You are now logged in';
  header('Location: index.php');
}



function is_logged_in(){
  if(isset($_SESSION['login_user']) && $_SESSION['login_user']> 0){
    return true;
  }
  return false;
}

function login_error_redirect($url='login.php'){
  $_SESSION['error_flash'] ='You must be logged in to view  that page';
  header('Location: '.$url);
}
function isLoginSessionExpired() {
  $autologout=1800;
  $lastactive = $_SESSION['timestamp'] ?? 0;
  if (time()-$lastactive>$autologout){
  	    $_SESSION = array();                   // Clear the session data
                  setcookie(session_name("login_user"), false, time()-3600);     // Clear the cookie
                 session_destroy();                         // Destroy the session data
  }else {
  		$_SESSION['timestamp']=time();              //Or reset the timestamp
  	}
}

function permission_error_redirect($url='login.php'){
  $_SESSION['error_flash'] ='You do not have permission to access that page';
  header('Location: '.$url);
}
function  has_permission($permission='Admin'){
  global $user_data;
  $permissions=explode(',', $user_data['permissions']);
  if(in_array($permission,$permissions,true)){
    return true;
  }
  return false;
}
function delete($table,$colName,$id){
  global $connection;
  $query =mysqli_query($connection, "DELETE FROM $table WHERE $colName =$id ");
  if ($query){
    return true;
  }else{
    return false;
  }
}
function confirm($id){
    global $connection;
  $query =mysqli_query($connection, "SELECT status FROM comment WHERE id =$id");
  if(mysqli_num_rows($query)> 0){
  $result=mysqli_fetch_array($query);
  $status =$result['status'];
  //check connection_status();
  if ($status == 'Unapproved'){
    $sql =mysqli_query($connection,"UPDATE comment SET status='Approved'WHERE id='$id' ");
  }else{
      $sql =mysqli_query($connection,"UPDATE comment SET status='Unapproved'WHERE id='$id' ");
       }

       return true;
  }

  else{
    return false;
  }
}
//redirect helper
function redirect($page= 'index.php'){
  header("Location:".$page."");
}
function pretty_date($date){
  return date("M d, Y h:i A",strtotime($date));
}
?>
