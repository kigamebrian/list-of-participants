<?php include 'includes/header.php';
$sql = "SELECT * FROM components";
$res = mysqli_query($connection, $sql);

 ?>
  <div class="main">
    <div class="container">

      <div class="row">
        <br>
        <div class="col-md-12 text-center">
          <img src="imgs/logo-upops-2.jpg" alt="logo-upops-2">
        </div>
        <div class="col-md-12  headtitle">
          <h1 class="text-center heading">List of Participants</h1>
          <hr>

        </div>

        <div class="col-md-12 component">


        <table  class="table  border-0 display">
          <thead class="bg-success white"><th>#</th><th>Component Title</th> <th>Action</th></thead>
          <?php
            $i=1;
            while ($row = mysqli_fetch_array($res)) {
              $comp_id=$row['id'];
              $comp_title = $row['component_title'];

            ?>
          <tr>


            <th class="border-0"scope="row"><?=$i;?></th>
              <td class="border-0"><?=$comp_title;?></td>
              <td class="border-0"><a href="view.php?component-id=<?=$comp_id;?>">view </a></td>



          </tr>
          <?php
          $i++;
        }
           ?>
        </table>

      </div>
      </div>


      <div class="row logoall">
        <div class="col-md-12">
          <hr>
        </div>
        <div class="col-md-4 text-center" >
          <img src="imgs/logo1.jpg" alt="logo1"style="height:100px;width:100px;">

        </div>
        <div class="col-md-4 text-center">
          <img src="imgs/logo2.png" alt="logo2"style="height:100px;width:100px;">

        </div>
        <div class="col-md-4 text-center">
          <img src="imgs/logo3.png" alt="logo3"style="height:100px;width:100px;">

        </div>

      </div>

    </div>


  </body>
</html>
