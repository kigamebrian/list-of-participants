<?php include 'includes/header.php';
$sql = "SELECT * FROM components";
$res = mysqli_query($connection, $sql);
$cid=$_REQUEST['component-id'];
 ?>
  <div class="main">
    <div class="container">

      <div class="row">
        <div class="col-md-12 text-center">
          <img src="imgs/logo-upops-2.jpg" alt="logo-upops-2">
        </div>
        <div class="col-md-12  headtitle">
          <h1 class="text-center heading">List of Participants</h1>
          <hr>

        </div>

        <div class="col-md-12 component">


          <?php
          $sql = "SELECT * FROM participants WHERE participant_component_id ='$cid' " ;
          $rs_result = $connection->query($sql);

          ?>
            <table  class="table  border-0 display " id="tblexportData"style="width:1000px;margin: 0 auto;">

                <thead class="bg-success white"><th>#</th><th>Name</th> <th>Institution</th><th>Email</th></thead>
                  <tbody>
                <?php
                $i=1;
                while ($row = mysqli_fetch_assoc($rs_result)) {
                ?>



                <tr>
                <th class="border-0"scope="row"><?php echo $i;?></th>
                <td class="border-0"><?php echo $row["name"]; ?></td>
                <td class="border-0"><?php echo $row["institution"]; ?></td>
                <td class="border-0"><?php echo $row["email"]; ?></td>
              </tr>

              <?php
              $i++;
              };
              ?>
                </tbody>
            </table>
            <br>
            <br>
      </div>
      <button onclick="goBack()" class="btn btn-success">Go Back</button>
      </div>


      <div class="row logoall">
        <div class="col-md-12">
          <hr>
        </div>
        <div class="col-md-4 text-center" >
          <img src="imgs/logo1.jpg" alt="logo1"style="height:100px;width:100px;">

        </div>
        <div class="col-md-4 text-center">
          <img src="imgs/logo2.png" alt="logo2"style="height:100px;width:100px;">

        </div>
        <div class="col-md-4 text-center">
          <img src="imgs/logo3.png" alt="logo3"style="height:100px;width:100px;">

        </div>

      </div>

    </div>

    <script type="text/javascript">
      $(document).ready(function() {
        $('#tblexportData').DataTable( {
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                'pdfHtml5'
            ]
        } );
      } );
      function goBack() {
        window.history.back();
      }
    </script>



  </body>
</html>
